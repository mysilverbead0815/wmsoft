
mysql info

in database_connection.php
$connect = new PDO("mysql:host=localhost;dbname=chat;charset=utf8mb4", "root", "scb123");

login info for testing (id/password)

johnsmith / password
test01 / test01
peterParker / password
davidMoore / password